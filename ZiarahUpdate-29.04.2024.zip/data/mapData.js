export const itenaryPlaces = {
        "Al Hada Mountain" : {
            "lat": 21.366788268731277,
            "lng": 40.28406500914232
          },
          "Abdullah Ibn Abbas Mosque" : {
            "lat": 21.27061250062932,
            "lng": 40.40819347145445
          },
          "Addas Mosque" : {
            "lat": 21.257854860603686,
            "lng": 40.39081523732379
          },
          "Alkou Mosque" : {
            "lat": 21.2572990034989,
            "lng": 40.3868909291242
          },
          "Ziarat in Taif - Historical Mosque" : {
            "lat": 21.256641532953005,
            "lng": 40.39123663163541
          },
          "Jeddah" : {
            "lat": 21.54338648338733,
            "lng": 39.142146180373985
          },
          "Al-Balad" : {
            "lat": 21.48138600911174,
            "lng": 39.1872779895021
          },
          "Biet Nassif" : {
            "lat": 21.484280564554922,
            "lng": 39.187587466166754
          },
          "Jeddah Corniche" : {
            "lat": 21.603235654225887,
            "lng": 39.107708404385114
          },
          "Jabal al-Hira" : {
            "lat": 26.94615687090991,
            "lng": 41.12480795335652
          },
          "Masjid al-Jinn" : {
            "lat": 21.433665264760748,
            "lng": 39.82891145082038
          },
          "Muzdalifah" : {
            "lat": 21.409088616577712,
            "lng": 39.898678423836756
          },
          "Mount Arafat" : {
            "lat": 21.35584383659143,
            "lng": 39.98407300426587
          },
          "Mina" : {
            "lat": 21.414881057207115,
            "lng": 39.89416435499167
          },
          "Jabal Thawr" : {
            "lat": 21.37342171097016,
            "lng": 39.85552298548265
          },
          "Kaaba" : {
            "lat": 21.422777508283314,
            "lng": 39.826138070130696
          },
          "Kaaba and Mina" : {
            "lat": 21.422777508283314,
            "lng": 39.826138070130696
          },
          "Jamarat" : {
            "lat": 21.422185294841242,
            "lng": 39.87639537965634
          },
          "Arafat" : {
            "lat": 21.355963742450328,
            "lng": 39.98398717357643
          },
          "Arrival in Mecca" : {
            "lat": 21.432099860245206,
            "lng": 39.81082030317928
          },
          "Day 1: Arrival in Makkah" : {
            "lat": 21.432099860245206,
            "lng": 39.81082030317928
          },
          "Day 2: Makkah" : {
            "lat": 21.432099860245206,
            "lng": 39.81082030317928
          },
          "Day 3: Makkah - Ziarah and Umrah" : {
            "lat": 21.432099860245206,
            "lng": 39.81082030317928
          },
          "Day 4: Makkah" : {
            "lat": 21.432099860245206,
            "lng": 39.81082030317928
          },
          "Day 5: Makkah - Taif City Sightseeing and Umrah" : {
            "lat": 21.432099860245206,
            "lng": 39.81082030317928
          },
          "Day 6: Check Out from Hotel in Makkah - Travel to Madinah" : {
            "lat": 21.432099860245206,
            "lng": 39.81082030317928
          },
          "Day 7: Madinah - Visit Rawza Mubarak" : {
            "lat": 21.432099860245206,
            "lng": 39.81082030317928
          },
          "Day 8: Check Out from Madinah - Departure to Italy" : {
            "lat": 21.432099860245206,
            "lng": 39.81082030317928
          }
    }

